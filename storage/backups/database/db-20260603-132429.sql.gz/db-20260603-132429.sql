-- MySQL dump 10.13  Distrib 8.4.9, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: asset_management
-- ------------------------------------------------------
-- Server version	8.4.9-0ubuntu0.26.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES ('asset-management-cache-9127f7b1bc8cb96373d276bafe581072','i:1;',1780324598),('asset-management-cache-9127f7b1bc8cb96373d276bafe581072:timer','i:1780324598;',1780324598),('asset-management-cache-a6f155de15268698bea3ed1df3f9aab3','i:1;',1780469632),('asset-management-cache-a6f155de15268698bea3ed1df3f9aab3:timer','i:1780469632;',1780469632),('asset-management-cache-spatie.permission.cache','a:3:{s:5:\"alias\";a:4:{s:1:\"a\";s:2:\"id\";s:1:\"b\";s:4:\"name\";s:1:\"c\";s:10:\"guard_name\";s:1:\"r\";s:5:\"roles\";}s:11:\"permissions\";a:25:{i:0;a:4:{s:1:\"a\";i:1;s:1:\"b\";s:10:\"view-staff\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:2;i:1;i:3;i:2;i:4;}}i:1;a:4:{s:1:\"a\";i:2;s:1:\"b\";s:10:\"view-users\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:2;i:1;i:3;}}i:2;a:4:{s:1:\"a\";i:3;s:1:\"b\";s:14:\"view-companies\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:2;i:1;i:3;i:2;i:4;}}i:3;a:4:{s:1:\"a\";i:4;s:1:\"b\";s:12:\"view-devices\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:2;i:1;i:3;i:2;i:4;}}i:4;a:4:{s:1:\"a\";i:5;s:1:\"b\";s:10:\"view-roles\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:2;}}i:5;a:4:{s:1:\"a\";i:6;s:1:\"b\";s:10:\"edit-roles\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:2;}}i:6;a:4:{s:1:\"a\";i:7;s:1:\"b\";s:14:\"view-dashboard\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:2;i:1;i:3;i:2;i:4;}}i:7;a:4:{s:1:\"a\";i:8;s:1:\"b\";s:11:\"create-user\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:2;}}i:8;a:4:{s:1:\"a\";i:9;s:1:\"b\";s:9:\"edit-user\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:2;}}i:9;a:4:{s:1:\"a\";i:10;s:1:\"b\";s:11:\"delete-user\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:2;}}i:10;a:4:{s:1:\"a\";i:11;s:1:\"b\";s:12:\"restore-user\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:2;}}i:11;a:4:{s:1:\"a\";i:12;s:1:\"b\";s:16:\"create-companies\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:2;}}i:12;a:4:{s:1:\"a\";i:13;s:1:\"b\";s:14:\"edit-companies\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:2;}}i:13;a:4:{s:1:\"a\";i:14;s:1:\"b\";s:16:\"delete-companies\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:2;}}i:14;a:4:{s:1:\"a\";i:15;s:1:\"b\";s:17:\"restore-companies\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:2;}}i:15;a:4:{s:1:\"a\";i:16;s:1:\"b\";s:14:\"create-devices\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:2;i:1;i:3;i:2;i:4;}}i:16;a:4:{s:1:\"a\";i:17;s:1:\"b\";s:12:\"edit-devices\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:2;i:1;i:3;i:2;i:4;}}i:17;a:4:{s:1:\"a\";i:18;s:1:\"b\";s:14:\"delete-devices\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:2;i:1;i:4;}}i:18;a:4:{s:1:\"a\";i:19;s:1:\"b\";s:15:\"restore-devices\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:2;i:1;i:4;}}i:19;a:4:{s:1:\"a\";i:20;s:1:\"b\";s:20:\"update-device-status\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:2;i:1;i:4;}}i:20;a:4:{s:1:\"a\";i:21;s:1:\"b\";s:26:\"view-device-status-history\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:2;i:1;i:4;}}i:21;a:4:{s:1:\"a\";i:22;s:1:\"b\";s:12:\"create-staff\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:2;i:1;i:3;i:2;i:4;}}i:22;a:4:{s:1:\"a\";i:23;s:1:\"b\";s:10:\"edit-staff\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:3:{i:0;i:2;i:1;i:3;i:2;i:4;}}i:23;a:4:{s:1:\"a\";i:24;s:1:\"b\";s:12:\"delete-staff\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:2:{i:0;i:2;i:1;i:4;}}i:24;a:4:{s:1:\"a\";i:25;s:1:\"b\";s:13:\"restore-staff\";s:1:\"c\";s:3:\"web\";s:1:\"r\";a:1:{i:0;i:2;}}}s:5:\"roles\";a:3:{i:0;a:3:{s:1:\"a\";i:2;s:1:\"b\";s:5:\"Admin\";s:1:\"c\";s:3:\"web\";}i:1;a:3:{s:1:\"a\";i:3;s:1:\"b\";s:7:\"Manager\";s:1:\"c\";s:3:\"web\";}i:2;a:3:{s:1:\"a\";i:4;s:1:\"b\";s:10:\"Technician\";s:1:\"c\";s:3:\"web\";}}}',1780471027);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `companies`
--

DROP TABLE IF EXISTS `companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `companies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `tax_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `companies_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companies`
--

LOCK TABLES `companies` WRITE;
/*!40000 ALTER TABLE `companies` DISABLE KEYS */;
INSERT INTO `companies` VALUES (1,'Greatlakes','info@greatlakes.local',NULL,NULL,NULL,NULL,'active','2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(2,'Rafiki','info@rafiki.local',NULL,NULL,NULL,NULL,'active','2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(3,'Allmol','info@allmol.local',NULL,NULL,NULL,NULL,'active','2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(4,'TBP','info@tbp.local',NULL,NULL,NULL,NULL,'active','2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(5,'Beem','info@beem.local',NULL,NULL,NULL,NULL,'active','2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(6,'Integrity','info@integrity.local',NULL,NULL,NULL,NULL,'active','2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(7,'Kahe','info@kahe.local',NULL,NULL,NULL,NULL,'active','2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(8,'HAPATWA','info@hapatwa.local',NULL,NULL,NULL,NULL,'active','2026-05-23 19:41:18','2026-05-23 19:41:18',NULL);
/*!40000 ALTER TABLE `companies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_status_histories`
--

DROP TABLE IF EXISTS `device_status_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `device_status_histories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `device_id` bigint unsigned NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `changed_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `device_status_histories_device_id_foreign` (`device_id`),
  KEY `device_status_histories_changed_by_foreign` (`changed_by`),
  CONSTRAINT `device_status_histories_changed_by_foreign` FOREIGN KEY (`changed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `device_status_histories_device_id_foreign` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_status_histories`
--

LOCK TABLES `device_status_histories` WRITE;
/*!40000 ALTER TABLE `device_status_histories` DISABLE KEYS */;
INSERT INTO `device_status_histories` VALUES (1,135,'offline','',2,'2026-05-29 07:02:37','2026-05-29 07:02:37'),(2,123,'online','',2,'2026-05-29 09:41:15','2026-05-29 09:41:15'),(3,206,'retired','',2,'2026-05-29 09:41:30','2026-05-29 09:41:30'),(4,141,'online','',2,'2026-05-29 09:41:47','2026-05-29 09:41:47');
/*!40000 ALTER TABLE `device_status_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `devices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `staff_id` bigint unsigned DEFAULT NULL,
  `asset_tag` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `serial_number` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `manufacturer` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'e.g., Laptop, Desktop, Server, Mobile, Network Equipment',
  `operating_system` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `os_version` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `processor` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ram_gb` int DEFAULT NULL COMMENT 'RAM in GB',
  `storage_gb` int DEFAULT NULL COMMENT 'Storage in GB',
  `storage_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'e.g., SSD, HDD, NVMe',
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'IPv4 or IPv6',
  `mac_address` varchar(17) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'MAC address format: XX:XX:XX:XX:XX:XX',
  `hostname` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Physical location, e.g., Office, Room, Desk',
  `status` enum('active','offline','online','formatted','dead','under_repair','retired') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `purchase_date` date DEFAULT NULL,
  `purchase_cost` decimal(10,2) DEFAULT NULL COMMENT 'Purchase cost in currency',
  `warranty_expiry` date DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `devices_asset_tag_unique` (`asset_tag`),
  UNIQUE KEY `devices_serial_number_unique` (`serial_number`),
  KEY `devices_company_id_index` (`company_id`),
  KEY `devices_staff_id_index` (`staff_id`),
  KEY `devices_asset_tag_index` (`asset_tag`),
  KEY `devices_serial_number_index` (`serial_number`),
  KEY `devices_status_index` (`status`),
  KEY `devices_device_type_index` (`device_type`),
  CONSTRAINT `devices_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `devices_staff_id_foreign` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=211 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devices`
--

LOCK TABLES `devices` WRITE;
/*!40000 ALTER TABLE `devices` DISABLE KEYS */;
INSERT INTO `devices` VALUES (1,1,1,'GL-23',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-23',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(2,1,2,'GL-24',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-24',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(3,1,3,'GL-19',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-19',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(4,1,4,'GL-31',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-31',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(5,1,5,'GL-29',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-29',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(6,1,6,'GL-43',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-43',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(7,1,7,'GL-07',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-07',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(8,1,8,'GL-09',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-09',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(9,1,9,'GL-22',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-22',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(10,1,10,'GL-12',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-12',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(11,1,11,'GL-28',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-28',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(12,1,12,'GL-42',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-42',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(13,1,13,'GL-37',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-37',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(14,1,14,'GL-47',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-47',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(15,1,15,'GL-39',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-39',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(16,1,16,'GL-10',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-10',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(17,1,17,'GL-41',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-41',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(18,1,18,'GL-32',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-32',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(19,1,19,'GL-SPARE',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-SPARE',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(20,1,20,'GL-36',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-36',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(21,1,21,'GL-08',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-08',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(22,1,22,'GL-14',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-14',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(23,1,23,'GL-32-2',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-32',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(24,1,24,'GL-30',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-30',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(25,1,25,'GL-20',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-20',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(26,1,26,'GL-44',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-44',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(27,1,27,'GL-04',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-04',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(28,1,28,'GL-13',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-13',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(29,1,29,'GL-38',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-38',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(30,1,30,'GL-51',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-51',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(31,1,31,'GL-17',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-17',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(32,1,32,'GL-45',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-45',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(33,1,33,'GL-49',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-49',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(34,1,34,'GL-18',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GL-18',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(35,1,35,'PENDING-GL-35',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'offline',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(36,1,36,'PENDING-GL-36',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'offline',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(37,1,37,'PENDING-GL-37',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'offline',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(38,1,38,'PENDING-GL-38',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'offline',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(39,1,39,'PENDING-GL-39',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'offline',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(40,1,40,'PENDING-GL-40',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'offline',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(41,1,41,'PENDING-GL-41',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'offline',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(42,1,42,'PENDING-GL-42',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'offline',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(43,2,43,'DESKTOP-S5MRECJ',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'DESKTOP-S5MRECJ',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(44,2,44,'RAFIKI1',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'RAFIKI1',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(45,2,45,'TELLER2',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TELLER2',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(46,2,46,'RAFIKIFOREX',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'RAFIKIFOREX',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(47,2,47,'rafiki2',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'rafiki2',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(48,2,48,'rafiki3',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'rafiki3',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(49,2,49,'RAFIKIFOREX-2',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'RAFIKIFOREX',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(50,2,50,'PENDING-RF-8',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'offline',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(51,2,51,'PENDING-RF-9',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'offline',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(52,2,52,'PENDING-RF-10',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'offline',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(53,2,53,'PENDING-RF-11',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'offline',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(54,2,54,'PENDING-RF-12',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'offline',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(55,2,55,'PENDING-RF-13',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'offline',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(56,3,56,'DESKTOP-T440E89',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'DESKTOP-T440E89',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(57,3,57,'DESKTOP-T301A78',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'DESKTOP-T301A78',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(58,3,58,'ALL-03-DEC',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ALL-03-DEC',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(59,3,59,'ALL-25-DEC',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ALL-25-DEC',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(60,3,60,'PENDING-ALL-5',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(61,3,61,'ALL-05-ADM',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ALL-05-ADM',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(62,3,62,'ALL-04-ADM',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ALL-04-ADM',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(63,3,63,'ALL-25',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ALL-25',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(64,3,64,'ALL-10-FIN',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ALL-10-FIN',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(65,3,65,'ALL-08-ADM',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ALL-08-ADM',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(66,3,66,'ALL-ADM',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ALL-ADM',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(67,3,67,'DESKTOP-34GHJMA',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'DESKTOP-34GHJMA',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(68,3,68,'ALL-11-FIN',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ALL-11-FIN',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(69,3,69,'ALL-17-SHI',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ALL-17-SHI',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(70,3,70,'ALL-07-ADM',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ALL-07-ADM',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(71,3,71,'ALL-26-DEC',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ALL-26-DEC',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(72,3,72,'ALL-14-TRA',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ALL-14-TRA',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(73,3,73,'Allmol-Hr',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Allmol-Hr',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(74,3,74,'ALL-15-TRA-1',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ALL-15-TRA',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(75,3,75,'ALL-15-TRA-2',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ALL-15-TRA',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(76,3,76,'ALL-13-TRA',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ALL-13-TRA',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(77,3,77,'ALL-19-FIN',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ALL-19-FIN',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(78,3,78,'ALL-12-FIN',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ALL-12-FIN',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(79,3,79,'ALL-20-27-FIN',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ALL-20-27-FIN',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(80,3,80,'ALL-20-ADM',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ALL-20-ADM',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(81,3,81,'ALL-FIN',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ALL-FIN',NULL,'offline',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(82,3,82,'ALL-06-ADM',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ALL-06-ADM',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(83,3,83,'DESKTOP-10SPTP6',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'DESKTOP-10SPTP6',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(84,3,84,'DESKTOP-CGLU1UB',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'DESKTOP-CGLU1UB',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(85,3,85,'PENDING-ALL-30',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(86,3,86,'PENDING-ALL-31',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(87,4,87,'TBPL-01',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-01',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(88,4,88,'TBPL-14',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-14',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(89,4,89,'TBPL-17',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-17',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(90,4,90,'TBPL-18',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-18',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(91,4,91,'TBPL-31',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-31',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(92,4,92,'TBPL-02',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-02',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(93,4,93,'TBPL-35',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-35',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(94,4,94,'TBPL-36',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-36',NULL,'offline',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(95,4,95,'TBPL-30',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-30',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(96,4,96,'TBPL-05',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-05',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(97,4,97,'TBPL-28',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-28',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(98,4,98,'TBPL-20',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-20',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(99,4,99,'TBPL-21',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-21',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(100,4,100,'TBPL-19',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-19',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(101,4,101,'TBPL-08',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-08',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(102,4,102,'TBPL-45',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-45',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(103,4,103,'TBPL-22',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-22',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(104,4,104,'TBPL-06',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-06',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(105,4,105,'TBPL-37',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-37',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(106,4,106,'TBPL-07',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-07',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(107,4,107,'TBPL-16',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-16',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(108,4,108,'TBPL-03',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-03',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(109,4,109,'TBPL-12',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-12',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(110,4,110,'TBPL-09',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-09',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(111,4,111,'TBPL-38',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-38',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(112,4,112,'TBPL-34',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-34',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(113,4,113,'TBPL-23',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-23',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(114,4,114,'TBPL-32',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-32',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(115,4,115,'TBPL-50',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-50',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(116,4,116,'TBPL-11',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-11',NULL,'offline',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(117,4,117,'TBPL-10',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-10',NULL,'offline',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(118,4,118,'TBPL-41',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-41',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(119,4,119,'TBPL-39',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-39',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(120,4,120,'TBPL-40',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-40',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(121,4,121,'TBPL-52',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-52',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(122,4,122,'TBPL-21-2',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TBPL-21',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(123,5,123,'BM-25','PC00CX1B','Generic','Lenovo','Laptop','Windows','Windows 10 (22H2)','Intel(R) Core(TM) i5-4300M CPU @ 2.60GHz',8,466,NULL,NULL,NULL,'BM-25',NULL,'online',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-29 09:41:15',NULL),(124,5,124,'BM-14','PF3T2MCA','Generic','Lenovo','Laptop','Windows','Windows 11 (24H2)','12th Gen Intel(R) Core(TM) i7-1280P',NULL,NULL,NULL,NULL,NULL,'BM-14',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-29 08:33:58',NULL),(125,5,125,'BEEM-13','PF1FRZX7','Generic','Lenovo','Laptop','Windows','Windows 11 (24H2)','Intel(R) Core(TM) i5-8350U CPU @ 1.70GHz',16,238,NULL,NULL,NULL,'BEEM-13',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-29 08:32:26',NULL),(126,5,126,'BMS-09','PC0KCM1T','Generic','Lenovo','Laptop','Windows','Windows 11 (24H2)','Intel(R) Core(TM) i5-6300U CPU @ 2.40GHz',16,238,NULL,NULL,'F4:8C:50:95:EB:CE','BMS-09',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-29 08:25:26',NULL),(127,5,127,'BM-07','MP2KZH7V','Generic','Lenovo','Laptop','Windows','Windows 11 (24H2)','12th Gen Intel(R) Core(TM) i5-1235U',16,477,NULL,NULL,'E4:0D:36:69:BA:D6','BM-07',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-29 08:20:54',NULL),(128,5,128,'BM-03','MP2KZH6Q','Generic','Lenovo','Laptop','Windows','Windows 11 (24H2)','12th Gen Intel(R) Core(TM) i5-1235U',16,477,NULL,NULL,NULL,'BM-03',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-29 08:19:05',NULL),(129,5,129,'BM-26','MP2L3FXJ','Generic','Lenovo','Laptop','Windows','Windows 11 (24H2)','12th Gen Intel(R) Core(TM) i5-1235U',24,477,NULL,NULL,NULL,'BM-26',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-29 09:07:16',NULL),(130,5,130,'BM-10','MP2ESCMK','Generic','Lenovo','Laptop','Windows','Windows 11 (24H2)','11th Gen Intel(R) Core(TM) i5-1135G7 @ 2.40GHz',20,238,NULL,NULL,NULL,'BM-10',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-29 08:16:12',NULL),(131,5,131,'BM-06','MP2ERCH6','Generic','Lenovo','Laptop','Windows','Windows 11 (24H2)','11th Gen Intel(R) Core(TM) i5-1135G7 @ 2.40GHz',NULL,NULL,NULL,NULL,NULL,'BM-06',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-29 08:14:38',NULL),(132,5,132,'BM-02','MP2ESEZ3','Generic','Lenovo','Laptop','Windows','Windows 11 (24H2)','11th Gen Intel(R) Core(TM) i5-1135G7 @ 2.40GHz',20,238,NULL,NULL,NULL,'BM-02',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-29 08:11:40',NULL),(133,5,133,'BM-11','PF1ESRKW','Generic','Lenovo','Laptop','Windows','windows 11','Intel(R) Core(TM) i7-8650U CPU @ 1.90GHz',16,477,NULL,NULL,NULL,'BM-11',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-29 06:55:33',NULL),(134,5,134,'BM-04','MP2ESCKB','Generic','Lenovo','Laptop','Windows','Windows 11 (24H2)','11th Gen Intel(R) Core(TM) i5-1135G7 @ 2.40GHz',20,238,NULL,NULL,NULL,'BM-04',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-29 08:08:58',NULL),(135,5,135,'BM-19','PW09TRJT','Generic','Lenovo','Laptop','Windows','Windows 11 (24H2)','13th Gen Intel(R) Core(TM) i5-1335U',24,477,NULL,NULL,NULL,'BM-19',NULL,'online',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-29 08:06:31',NULL),(136,5,136,'BMS-11','PF1GFG8H','Generic','Lenovo','Laptop','Windows','Windows 11 (24H2)','Intel(R) Core(TM) i5-8350U CPU @ 1.70GHz',16,238,NULL,NULL,NULL,'BMS-11',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-29 09:03:22',NULL),(137,5,137,'BM-22','PW0EC61J','Generic','Lenovo','Laptop','Windows','Windows 11 (24H2)','13th Gen Intel(R) Core(TM) i5-13420H',32,477,NULL,NULL,NULL,'BM-22',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-29 07:59:00',NULL),(138,5,138,'BM-09','PF1HXNR3','Generic','Lenovo','Laptop','Windows','Windows 11 (24H2)','Intel(R) Core(TM) i5-8350U CPU @ 1.70GHz',16,238,NULL,NULL,NULL,'BM-09',NULL,'offline',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-29 08:22:12',NULL),(139,5,139,'BM-32','MP2KZH60','Generic','Lenovo','Laptop','Windows','Windows 11 (24H2)','12th Gen Intel(R) Core(TM) i5-1235U',16,477,NULL,NULL,NULL,'BM-32',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-29 07:53:28',NULL),(140,5,140,'BM-28','PF1GWB15','Generic','Lenovo','Laptop','Windows','Windows 11 (24H2)','Intel(R) Core(TM) i5-8350U CPU @ 1.70GHz',24,238,NULL,NULL,NULL,'BM-28',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-29 07:49:33',NULL),(141,5,141,'BM-27','PW0EC614','Generic','Lenovo','Laptop','Windows','windows 11','13th Gen Intel(R) Core(TM) i5-13420H',32,477,NULL,NULL,NULL,'BM-27',NULL,'online',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-29 09:41:47',NULL),(142,5,142,'BM-15','MP2L3FX6','Generic','Lenovo','Laptop','Windows','Windows 11 (24H2)','12th Gen Intel(R) Core(TM) i5-1235U',16,477,NULL,NULL,NULL,'BM-15',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-29 07:37:03',NULL),(143,5,143,'BM-16','MP2BK2V4','Generic','Lenovo','Laptop','Windows','Windows 11 (24H2)','12th Gen Intel(R) Core(TM) i5-1235U',16,238,NULL,NULL,NULL,'BM-16',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-29 07:30:54',NULL),(144,5,144,'BM-21','PF3T2MDD','Generic','Lenovo','Laptop','Windows','windows 11','12th Gen Intel(R) Core(TM) i7-1280P',32,954,NULL,NULL,NULL,'BM-21',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-29 07:15:11',NULL),(145,5,145,'komi-ThinkBook-14-G6-IRL','PW09L9LA','Generic','Lenovo','Laptop','Linux','Ubuntu 24.04.4 LTS (Noble Numbat)','13th Gen Intel(R) Core(TM) i5-1335U',32,256,NULL,NULL,NULL,'komi-ThinkBook-14-G6-IRL',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-29 07:35:04',NULL),(146,5,146,'BM-30','MP2KZH7E','Generic','Lenovo','Laptop','Linux','Ubuntu 24.04.4 LTS (Noble Numbat)','	12th Gen Intel(R) Core(TM) i5-1235U',16,512,NULL,NULL,NULL,'BM-30',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-29 09:35:00',NULL),(147,5,147,'Beem-PM-Macbook','H1QM6W5J2T','Apple','Apple','Laptop','Mac OS','macOS Tahoe 26.5 (25F71)','Apple M4',16,500,NULL,NULL,NULL,'Beem-PM-Macbook',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-29 07:27:45',NULL),(148,5,148,'hagai-ThinkBook-14-G6-IRL','PW09L9N6','Generic','Lenovo','Laptop','Linux','Ubuntu 24.04.4 LTS (Noble Numbat)','13th Gen Intel(R) Core(TM) i5-1335U',16,256,NULL,NULL,NULL,'hagai-ThinkBook-14-G6-IRL',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-29 07:22:50',NULL),(149,5,149,'admin-thinkbook-14-g4-iap','MP2KZH7S','Generic','Lenovo','Laptop','Linux','Ubuntu 22.04.5 LTS (Jammy Jellyfish)','12th Gen Intel(R) Core(TM) i5-1235U',16,512,NULL,NULL,NULL,'admin-thinkbook-14-g4-iap',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-29 07:17:57',NULL),(150,5,150,'BM-19-2','PW09TRJQ','Generic','Lenovo','Laptop','Linux','	Ubuntu 22.04.5 LTS (Jammy Jellyfish)','13th Gen Intel(R) Core(TM) i5-1335U',24,512,NULL,NULL,NULL,'BM-19',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-29 07:01:44',NULL),(151,5,151,'BM-30-2','MP2L3FWL','Generic','Lenovo','Laptop','Windows','windows 11','12th Gen Intel(R) Core(TM) i5-1235U',16,477,NULL,NULL,NULL,NULL,NULL,'offline',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-29 06:58:02',NULL),(152,6,152,'PENDING-INT-1',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'offline',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(153,6,153,'INTE-14',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'INTE-14',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(154,6,154,'INTE-21',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'INTE-21',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(155,6,155,'INTE-11',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'INTE-11',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(156,6,156,'INTE-12',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'INTE-12',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(157,6,157,'INTE-13',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'INTE-13',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(158,6,158,'INTE-10',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'INTE-10',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(159,6,159,'INTE-09',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'INTE-09',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(160,6,160,'INTE-22',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'INTE-22',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(161,6,161,'INTE-06',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'INTE-06',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(162,6,162,'INTE-05',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'INTE-05',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(163,6,163,'INTE-04',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'INTE-04',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(164,6,164,'INTE-17',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'INTE-17',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(165,6,165,'INT-16',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'INT-16',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(166,6,166,'INTE-03',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'INTE-03',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(167,6,167,'INT-20',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'INT-20',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(168,6,168,'INTE-15',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'INTE-15',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(169,7,169,'PENDING-KAH-1',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'offline',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(170,7,170,'KAHE-17',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'KAHE-17',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(171,7,171,'KAHE-16',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'KAHE-16',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(172,7,172,'KAHE-18',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'KAHE-18',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(173,7,173,'KAHE-09',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'KAHE-09',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(174,7,174,'KAHE-07',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'KAHE-07',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(175,7,175,'KAHE-08',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'KAHE-08',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(176,7,176,'INTE-07',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'INTE-07',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(177,7,177,'KAHE-10',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'KAHE-10',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(178,7,178,'KAJE-07',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'KAJE-07',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(179,7,179,'KAHE-13',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'KAHE-13',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(180,7,180,'KAHE-05',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'KAHE-05',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(181,7,181,'KAHE-O1',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'KAHE-O1',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(182,7,182,'KAHE-02',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'KAHE-02',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(183,7,183,'KAHE-15',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'KAHE-15',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(184,7,184,'INTE-02',NULL,'Generic',NULL,'Desktop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'INTE-02',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(185,8,185,'HAPL-11',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'HAPL-11',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(186,8,186,'HAP-12',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'HAP-12',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(187,8,187,'HAP-13',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'HAP-13',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(188,8,188,'HAP-11',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'HAP-11',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(189,8,189,'HAP-02',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'HAP-02',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(190,8,190,'HAP-15',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'HAP-15',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(191,8,191,'HAP-17',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'HAP-17',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(192,8,192,'HAP-14',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'HAP-14',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(193,8,193,'HAP-16',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'HAP-16',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(194,8,194,'HAP-01',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'HAP-01',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(195,8,195,'HAP-06',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'HAP-06',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(196,8,196,'HAP-04',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'HAP-04',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(197,8,197,'HAP-03',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'HAP-03',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(198,8,198,'HAP-07',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'HAP-07',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(199,8,199,'HAP-08',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'HAP-08',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(200,8,200,'HAP-09',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'HAP-09',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(201,8,201,'HAPL-05',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'HAPL-05',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(202,8,202,'HAPL-21',NULL,'Generic',NULL,'Laptop',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'HAPL-21',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(203,5,NULL,'BEEM-HOST','CZC8017LP3','Unknown',NULL,'Server',NULL,NULL,'Intel(R) Core(TM) i5-7500 CPU @ 3.40GHz',4,238,'SSD','192.168.1.250','18:60:24:7E:83:90','BEEM-HOST',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 16:54:06','2026-05-23 17:08:57',NULL),(204,5,NULL,'Beem-DC1',NULL,'Unknown','Microsoft Corporation','Server','Windows','Windows Server 2022','Intel(R) Core(TM) i5-7500 CPU @ 3.40GHz',2,127,'SSD','192.168.1.254','00:15:5D:01:74:01','Beem-DC1',NULL,'active',NULL,NULL,NULL,'Virtual Machinery','2026-05-23 17:11:45','2026-05-29 08:54:45',NULL),(205,5,NULL,'BEEM-BU','CZC8017LLF','Unknown','HP','Server','Windows','Windows Server 2022','Intel(R) Core(TM) i5-7500 CPU @ 3.40GHz',8,238,'SSD','192.168.1.251','3C:52:82:72:FF:8F','BEEM-BU',NULL,'active',NULL,NULL,NULL,NULL,'2026-05-23 17:17:27','2026-05-29 08:48:51',NULL),(206,5,141,'BM-18','PF0TGBSJ','20JNS1591G','Lenovo','Laptop','Windows','Microsoft Windows 11 Pro 10.0.22631','Intel(R) Core(TM) i5-6300U CPU @ 2.40GHz',16,238,NULL,NULL,NULL,NULL,NULL,'online',NULL,NULL,NULL,NULL,'2026-05-29 09:16:11','2026-06-01 09:46:22',NULL),(207,4,NULL,'TBP-HOST2','D98GD22','Generic','Dell Inc.','Server','Windows','Windows Server 2022','Intel(R) Xeon(R) CPU E3-1230 V2 @ 3.30GHz',NULL,NULL,NULL,'192.168.2.240','D4:AE:52:D4:83:12','TBP-HOST2',NULL,'online',NULL,NULL,NULL,NULL,'2026-05-29 11:10:47','2026-05-29 11:10:47',NULL),(208,4,NULL,'TBP-HOST1','2H9J1G3','Generic','Dell Inc.','Server','Windows','Windows server 2022','Intel(R) Xeon(R) E-2224 CPU @ 3.40GHz',64,3725,'HDD','192.168.2.250','B8:CB:29:BD:4B:C2','TBP-HOST1',NULL,'online',NULL,NULL,NULL,NULL,'2026-05-29 11:16:12','2026-05-29 11:16:12',NULL),(209,4,NULL,'TBP-A',NULL,'Generic','Microsoft Corporation','Server','Windows','Windows Server 2019','Intel(R) Xeon(R) E-2224 CPU @ 3.40GHz',2,200,'HDD',NULL,NULL,'TBP-A',NULL,'online',NULL,NULL,NULL,'Virtual machinery','2026-05-29 11:20:52','2026-05-29 11:25:54',NULL),(210,4,NULL,'TBP-DC1','3147-5812-0707-3629-5986-6419-61','Generic','Microsoft Corporation','Server','Windows','Windows Server 2022','Intel(R) Xeon(R) E-2224 CPU @ 3.40GHz',4,200,NULL,'192.168.2.254','00:15:5D:96:F2:00','TBP-DC1',NULL,'online',NULL,NULL,NULL,'Virtual machinery','2026-05-29 11:25:03','2026-05-29 11:25:41',NULL);
/*!40000 ALTER TABLE `devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` smallint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2025_08_14_170933_add_two_factor_columns_to_users_table',1),(5,'2026_05_15_000001_create_companies_table',1),(6,'2026_05_15_000002_create_staff_table',1),(7,'2026_05_15_000003_create_devices_table',1),(8,'2026_05_16_000001_add_soft_deletes_to_users_table',1),(9,'2026_05_16_000004_create_device_status_histories_table',1),(10,'2026_05_16_000005_add_verification_code_to_users_table',1),(11,'2026_05_16_105207_create_permission_tables',1),(12,'2026_05_16_110233_create_notifications_table',1),(13,'2026_05_19_063216_add_timezone_to_users_table',1),(14,'2026_05_19_114819_create_personal_access_tokens_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\Models\\User',2),(4,'App\\Models\\User',3),(3,'App\\Models\\User',4),(2,'App\\Models\\User',5);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES ('5637403b-7fd0-4a26-924a-312b4651ec0b','App\\Notifications\\TechnicianBulkStatusUpdateReminder','App\\Models\\User',3,'{\"count\":174,\"message\":\"You have 174 devices requiring status updates.\",\"type\":\"status_reminder\",\"action_url\":\"http:\\/\\/localhost:8000\\/technician\"}',NULL,'2026-06-02 05:00:07','2026-06-02 05:00:07'),('6b5657df-eaec-44c3-a3bf-cd2d81efc400','App\\Notifications\\TechnicianBulkStatusUpdateReminder','App\\Models\\User',3,'{\"count\":174,\"message\":\"You have 174 devices requiring status updates.\",\"type\":\"status_reminder\",\"action_url\":\"http:\\/\\/localhost:8000\\/technician\"}',NULL,'2026-06-03 05:00:08','2026-06-03 05:00:08'),('86cb1f73-3f3f-40ff-aaff-c2b30c6e103f','App\\Notifications\\TechnicianBulkStatusUpdateReminder','App\\Models\\User',3,'{\"count\":174,\"message\":\"You have 174 devices requiring status updates.\",\"type\":\"status_reminder\",\"action_url\":\"http:\\/\\/localhost:8000\\/technician\"}',NULL,'2026-06-01 05:00:10','2026-06-01 05:00:10'),('9f6d1568-25b9-499a-b144-ce6b78c8b85f','App\\Notifications\\TechnicianBulkStatusUpdateReminder','App\\Models\\User',3,'{\"count\":174,\"message\":\"You have 174 devices requiring status updates.\",\"type\":\"status_reminder\",\"action_url\":\"http:\\/\\/localhost:8000\\/technician\"}',NULL,'2026-05-31 05:00:08','2026-05-31 05:00:08');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'view-staff','web','2026-05-23 07:38:12','2026-05-23 07:38:12'),(2,'view-users','web','2026-05-23 07:38:12','2026-05-23 07:38:12'),(3,'view-companies','web','2026-05-23 07:38:12','2026-05-23 07:38:12'),(4,'view-devices','web','2026-05-23 07:38:12','2026-05-23 07:38:12'),(5,'view-roles','web','2026-05-23 07:38:12','2026-05-23 07:38:12'),(6,'edit-roles','web','2026-05-23 07:38:12','2026-05-23 07:38:12'),(7,'view-dashboard','web','2026-05-23 07:38:12','2026-05-23 07:38:12'),(8,'create-user','web','2026-05-23 07:38:12','2026-05-23 07:38:12'),(9,'edit-user','web','2026-05-23 07:38:12','2026-05-23 07:38:12'),(10,'delete-user','web','2026-05-23 07:38:12','2026-05-23 07:38:12'),(11,'restore-user','web','2026-05-23 07:38:12','2026-05-23 07:38:12'),(12,'create-companies','web','2026-05-23 07:38:12','2026-05-23 07:38:12'),(13,'edit-companies','web','2026-05-23 07:38:12','2026-05-23 07:38:12'),(14,'delete-companies','web','2026-05-23 07:38:12','2026-05-23 07:38:12'),(15,'restore-companies','web','2026-05-23 07:38:12','2026-05-23 07:38:12'),(16,'create-devices','web','2026-05-23 07:38:12','2026-05-23 07:38:12'),(17,'edit-devices','web','2026-05-23 07:38:12','2026-05-23 07:38:12'),(18,'delete-devices','web','2026-05-23 07:38:12','2026-05-23 07:38:12'),(19,'restore-devices','web','2026-05-23 07:38:12','2026-05-23 07:38:12'),(20,'update-device-status','web','2026-05-23 07:38:12','2026-05-23 07:38:12'),(21,'view-device-status-history','web','2026-05-23 07:38:12','2026-05-23 07:38:12'),(22,'create-staff','web','2026-05-23 07:38:12','2026-05-23 07:38:12'),(23,'edit-staff','web','2026-05-23 07:38:12','2026-05-23 07:38:12'),(24,'delete-staff','web','2026-05-23 07:38:12','2026-05-23 07:38:12'),(25,'restore-staff','web','2026-05-23 07:38:12','2026-05-23 07:38:12');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`),
  KEY `personal_access_tokens_expires_at_index` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,2),(2,2),(3,2),(4,2),(5,2),(6,2),(7,2),(8,2),(9,2),(10,2),(11,2),(12,2),(13,2),(14,2),(15,2),(16,2),(17,2),(18,2),(19,2),(20,2),(21,2),(22,2),(23,2),(24,2),(25,2),(1,3),(2,3),(3,3),(4,3),(7,3),(16,3),(17,3),(22,3),(23,3),(1,4),(3,4),(4,4),(7,4),(16,4),(17,4),(18,4),(19,4),(20,4),(21,4),(22,4),(23,4),(24,4);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Super Admin','web','2026-05-23 07:38:12','2026-05-23 07:38:12'),(2,'Admin','web','2026-05-23 07:38:12','2026-05-23 07:38:12'),(3,'Manager','web','2026-05-23 07:38:13','2026-05-23 07:38:13'),(4,'Technician','web','2026-05-23 07:38:13','2026-05-23 07:38:13');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('9vuWpkWFQEpLg8CXI8XPM8q2NHrIRACbYKMH8KQO',2,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJJQURyUUpQT1l1Z0tCWHUyYmdmRkZuTkU5ZHhDT1N6WFJ4VUM2MDc5IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cLzEyNy4wLjAuMTo4MDAwXC9kYXNoYm9hcmQiLCJyb3V0ZSI6ImRhc2hib2FyZCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX0sImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjoyfQ==',1780469585),('bRu2W8yYrzF3t2VhFklUOyiPu3D6Bocbl811NBoH',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','eyJfdG9rZW4iOiIxdGpyY050ZFdITjVPSTQwZlRKS1hKNTBJTW91MmRNVExFVzN5RkNpIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cLzAuMC4wLjA6ODAwMCIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1780322045),('fgDWvd1frWat2w2vca7kiaBt8jnKAz2PIdx7MPRe',NULL,'192.168.1.7','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36','eyJfdG9rZW4iOiJ3ZkNTR3J6RVlJbW94NU84VXdONTJEd0RuakUzSUVuU3E3TTJITU1uIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cLzE5Mi4xNjguMS4yNDo4MDAwXC9sb2dpbiIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1780324555),('kl1WodN9yEyRl4VwkLqtdDRtPbrQqoRrp1QpmOlD',NULL,'192.168.1.18','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0','eyJfdG9rZW4iOiJ4V2JaV3l5bW5VSTNDWmtpQ2loQlM0c2k0YXFnWlA3M0VNOFNjbVZWIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cLzE5Mi4xNjguMS4yNDo4MDAwXC9sb2dpbiIsInJvdXRlIjoibG9naW4ifSwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119fQ==',1780481705),('Rf0ueI9ZH1pPHGYSg35MlMHLWDf4gA176smbYfRm',2,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJoUHk2TmYxWVFTbXJ5cXRKSEI1SFNWZGxCc1FUdzdDOUhvQ2w5UEIwIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cLzEyNy4wLjAuMTo4MDAwXC9kYXNoYm9hcmQiLCJyb3V0ZSI6ImRhc2hib2FyZCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX0sImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjoyfQ==',1780384627),('skoA2DEDnYzThJTLacXWf6OzTAXF7moVqGXUDJoi',NULL,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJJQU9jQUtTY1ozaHlpUkRaNW5zSW10aE5QQ0hiOWtlNXNadmdnYllTIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHA6XC9cL2xvY2FsaG9zdDo4MDAwIiwicm91dGUiOiJob21lIn0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1780322028),('uELsrVPKAirhffHNPErNGSsXIeYXWFvA5XHYRpiU',2,'127.0.0.1','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJIT3JEbVphZmJReEhlSkxza2lTTmFxM0dOVEhEOEMzYlBSNjZpVjAzIiwiX2ZsYXNoIjp7Im9sZCI6WyJtZXNzYWdlIl0sIm5ldyI6W119LCJfcHJldmlvdXMiOnsidXJsIjoiaHR0cDpcL1wvMTI3LjAuMC4xOjgwMDBcL3VzZXJzIiwicm91dGUiOiJ1c2Vycy5pbmRleCJ9LCJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI6Mn0=',1780324713),('zy0azYlhcvvcve61AXl4KktQ2EArjfmz8xNkPRK2',NULL,'127.0.0.1','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:151.0) Gecko/20100101 Firefox/151.0','eyJfdG9rZW4iOiJ1U1FjT2RCVEtpdUlCcDk4MkhEbzFxaGpDNEZwblEyM1hMVVhEVFFYIiwiX2ZsYXNoIjp7Im9sZCI6W10sIm5ldyI6W119LCJfcHJldmlvdXMiOnsidXJsIjoiaHR0cDpcL1wvMTI3LjAuMC4xOjgwMDBcL2xvZ2luIiwicm91dGUiOiJsb2dpbiJ9fQ==',1780324580);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `staff` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hire_date` date DEFAULT NULL,
  `salary` decimal(10,2) DEFAULT NULL,
  `employment_type` enum('full_time','part_time','contract','intern') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'full_time',
  `status` enum('active','inactive','on_leave','terminated') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `staff_email_unique` (`email`),
  KEY `staff_company_id_index` (`company_id`),
  KEY `staff_email_index` (`email`),
  KEY `staff_status_index` (`status`),
  CONSTRAINT `staff_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=203 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff`
--

LOCK TABLES `staff` WRITE;
/*!40000 ALTER TABLE `staff` DISABLE KEYS */;
INSERT INTO `staff` VALUES (1,1,'Abdukardir','Karimjee','abdukardir.karimjee@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(2,1,'Fatmabasra','Hussein','fatmabasra.hussein@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(3,1,'Mussa','Sadiki','mussa.sadiki@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(4,1,'Tariq','Hassan','tariq.hassan@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(5,1,'Pinky','N/A','pinky@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(6,1,'Ally','Tagilile','ally.tagilile@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(7,1,'Agnes','Mkonyi','agnes.mkonyi@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(8,1,'Angel','Mosha','angel.mosha@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(9,1,'Zainab','Liund','zainab.liund@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(10,1,'Eric','Moses','eric.moses1@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(11,1,'Eric','Moses','eric.moses2@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(12,1,'Agnes','Mkonyi','agnes.mkonyi2@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(13,1,'Mariam','Budodi','mariam.budodi@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(14,1,'Ahmed','Shaksy','ahmed.shaksy@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(15,1,'Zowa','Zabura','zowa.zabura@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(16,1,'Yasinta','Kateire','yasinta.kateire@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(17,1,'Faidha','Mohamed','faidha.mohamed@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(18,1,'Saitoti','Kuyeti','saitoti.kuyeti@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(19,1,'Bakari','Omari','bakari.omari1@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(20,1,'Bakari','Omari','bakari.omari2@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(21,1,'Lukas','Ng’ende','lukas.ngende@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(22,1,'Nassor','Khalid','nassor.khalid@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(23,1,'Athumani','Mjema','athumani.mjema@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(24,1,'Agnes','Ndonde','agnes.ndonde@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(25,1,'Mussa','Ilamlila','mussa.ilamlila@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(26,1,'Abdul','Iddy','abdul.iddy@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(27,1,'Gidion','Safisha','gidion.safisha1@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(28,1,'Erick','Kajuna','erick.kajuna@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(29,1,'Halifa','Shaweji','halifa.shaweji@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(30,1,'Emmnauel','Ruzegea','emmnauel.ruzegea@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(31,1,'Omari','Mgheni','omari.mgheni@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(32,1,'Yasinta','Katair','yasinta.katair@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(33,1,'Glory','Veddy','glory.veddy@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(34,1,'Gidion','Safisha','gidion.safisha2@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(35,1,'Santosh','Rane','santosh.rane@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(36,1,'Partha','Saradhi','partha.saradhi@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(37,1,'Meri','Kinoi','meri.kinoi@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(38,1,'Gulleth','N/A','gulleth@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(39,1,'Shukuru','N/A','shukuru@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(40,1,'Fahmy','N/A','fahmy@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(41,1,'Abbas','Azziz','abbas.azziz@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(42,1,'Eddah','Salama','eddah.salama@greatlakes.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(43,2,'User','N/A','user@rafiki.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(44,2,'Rafiki','pc','rafiki.pc@rafiki.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(45,2,'RAFIKI','BDC NO1','rafiki.bdc@rafiki.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(46,2,'Nazina','N/A','nazina@rafiki.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(47,2,'DELL','N/A','dell@rafiki.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(48,2,'SHAZIN','N/A','shazin@rafiki.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(49,2,'RAFIKIFOREX','N/A','rafikiforex@rafiki.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(50,2,'KALOKOLA','BWESHA','kalokola.bwesha@rafiki.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(51,2,'SIVA','SARMA','siva.sarma@rafiki.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(52,2,'PRISCA','JOHN','prisca.john@rafiki.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(53,2,'Zanzibar','Branch 1','zanzibar1@rafiki.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(54,2,'Zanzibar','Branch 2','zanzibar2@rafiki.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(55,2,'Zanzibar','Branch 3','zanzibar3@rafiki.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(56,3,'Othuman','MAkuka','othuman.makuka@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(57,3,'Josephine','Laideson','josephine.laideson@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(58,3,'Bahati','Kajiba','bahati.kajiba@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(59,3,'John','Mhagama','john.mhagama@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(60,3,'Mponjoli','Award','mponjoli.award@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(61,3,'Wendy','Mwambenja','wendy.mwambenja@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(62,3,'Fatma','Said','fatma.said@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(63,3,'Steven','Haule','steven.haule@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(64,3,'Maiya','Issa','maiya.issa@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(65,3,'Tasleem','Sanjan','tasleem.sanjan@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(66,3,'Krupa','Dhanji','krupa.dhanji@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(67,3,'Chaitali','Nair','chaitali.nair@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(68,3,'Abel','Sabastian','abel.sabastian@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(69,3,'Yahaya','Abedi','yahaya.abedi@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(70,3,'Godwin','Ugin','godwin.ugin@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(71,3,'Asaid','Hamily','asaid.hamily@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(72,3,'Baltazari','Marik','baltazari.marik@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(73,3,'Rose','Olomi','rose.olomi@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(74,3,'Fred','N/A','fred@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(75,3,'Martina','Mchiro','martina.mchiro@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(76,3,'Kai','Lim','kai.lim@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(77,3,'Sanjay','Senghania','sanjay.senghania@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(78,3,'Shuja','N/A','shuja@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(79,3,'Shazimin','N/A','shazimin@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(80,3,'Nazendra','N/A','nazendra@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(81,3,'Vishal','Pindeslinga','vishal.pindeslinga@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(82,3,'Shamila','Mdee','shamila.mdee@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(83,3,'Praneel','N/A','praneel@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(84,3,'Taiyeb','N/A','taiyeb@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(85,3,'MUSTAFA','N/A','mustafa@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(86,3,'HATIM','N/A','hatim@allmol.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(87,4,'GENOVEVA','N/A','genoveva@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(88,4,'TUMSIFU','N/A','tumsifu@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(89,4,'SANDE','N/A','sande@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(90,4,'EXPATUS','N/A','expatus@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(91,4,'AMINA','N/A','amina@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(92,4,'MAINTANANCE','N/A','maintanance@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(93,4,'IRENE','N/A','irene@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(94,4,'OPERATIONS','N/A','operations@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(95,4,'MOLLEL','N/A','mollel@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(96,4,'SAID','N/A','said@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(97,4,'SARAH','N/A','sarah@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(98,4,'TERESIA','N/A','teresia@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(99,4,'KHADIJA','N/A','khadija@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(100,4,'FATMA','N/A','fatma@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(101,4,'ALLYKHAN','N/A','allykhan@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(102,4,'TWAHA','HAMIS IT','twaha.hamis@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(103,4,'AGAPE','N/A','agape@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(104,4,'MWANAAKIDA','N/A','mwanaakida@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(105,4,'FARAJA','N/A','faraja@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(106,4,'ABUSHEIKH','N/A','abusheikh@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(107,4,'SAID','ADAM','said.adam@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(108,4,'ISAYA','N/A','isaya@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(109,4,'VIVA','N/A','viva@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(110,4,'REHEMA','N/A','rehema@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(111,4,'RWAMWASI','N/A','rwamwasi@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(112,4,'PRODUCTION','SERVICES','production.services@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(113,4,'ABDULQADIR','N/A','abdulqadir@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(114,4,'LAMIYA','N/A','lamiya@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(115,4,'NEEMA','N/A','neema@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(116,4,'SHABBIR','N/A','shabbir@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(117,4,'MURTAZA','N/A','murtaza@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(118,4,'TASADAK','TAYABAL','tasadak.tayabal@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(119,4,'MOHANDAS','N/A','mohandas@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(120,4,'DOMINICK','MARIKI','dominick.mariki@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(121,4,'TAHILY','N/A','tahily@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(122,4,'QUEEN','N/A','queen@tbp.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(123,5,'Leah','Kisambwe','leah.kisambwe@beem.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(124,5,'Alifiyah','Ganijee','alifiyah.ganijee@beem.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(125,5,'Trainee','N/A','trainee@beem.local',NULL,NULL,NULL,NULL,'intern','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(126,5,'Mufaddal','Patel','mufaddal.patel@beem.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(127,5,'Rebecca','AliA','rebecca.alia@beem.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(128,5,'Patricia','Chagulaa','patricia.chagulaa@beem.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(129,5,'Sarrah','Moawalla','sarrah.moawalla@beem.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(130,5,'Aliakber','Tayabali','aliakber.tayabali@beem.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(131,5,'Simrane','Valgi','simrane.valgi@beem.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(132,5,'Maria','Patel','maria.patel@beem.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(133,5,'Jamal','Hadji','jamal.hadji@beem.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(134,5,'Agatha','Kasoga','agatha.kasoga@beem.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(135,5,'Burhanuddin','Shabbir','burhanuddin.shabbir@beem.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(136,5,'Moiz','Yusufali','moiz.yusufali@beem.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(137,5,'Yusuf','Ahmed','yusuf.ahmed@beem.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(138,5,'Omary','Masanja','omary.masanja@beem.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(139,5,'Munira','Karimjee','munira.karimjee@beem.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(140,5,'Mitchelle','Michael','mitchelle.michael@beem.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(141,5,'Lucy','Peter','lucy.peter@beem.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(142,5,'Selamasha','Ahmed','selamasha.ahmed@beem.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(143,5,'Rasha','Kamal','rasha.kamal@beem.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(144,5,'Taha','Jiwaji','taha.jiwaji@beem.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(145,5,'komi','N/A','komi@beem.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(146,5,'Elikana','Magomba','elikana.magomba@beem.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(147,5,'Abubakar','Milan','abubakar.milan@beem.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(148,5,'Hagai','Samson','hagai.samson@beem.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(149,5,'Grant','Mwanza','grant.mwanza@beem.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(150,5,'Frank','Malisa','frank.malisa@beem.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(151,5,'Ali','Nanji','ali.nanji@beem.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(152,6,'Mr.','Singh','mr.singh@integrity.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(153,6,'Pariyarath','Nair','pariyarath.nair@integrity.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(154,6,'Grace','Kusaga','grace.kusaga@integrity.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(155,6,'Happines','Charles','happines.charles@integrity.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(156,6,'Suhailat','Kawe','suhailat.kawe@integrity.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(157,6,'Bertha','John','bertha.john@integrity.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(158,6,'Lokanadham','Pasupuleti','lokanadham.pasupuleti@integrity.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(159,6,'Vincy','Varghese','vincy.varghese@integrity.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(160,6,'Nicodemus','Mwasuka','nicodemus.mwasuka@integrity.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(161,6,'Abdallah','Gunda','abdallah.gunda@integrity.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(162,6,'Christian','Mahundi','christian.mahundi@integrity.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(163,6,'Farida','Abdallah','farida.abdallah@integrity.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(164,6,'Mdachi','Emmanuel','mdachi.emmanuel@integrity.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(165,6,'Justin','Nyingo','justin.nyingo@integrity.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(166,6,'Upendo','Kajoro','upendo.kajoro@integrity.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(167,6,'Idd','Said','idd.said@integrity.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(168,6,'Michael','Kileo','michael.kileo@integrity.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(169,7,'Lugoda','N/A','lugoda@kahe.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(170,7,'Geoffrey','Dedeh','geoffrey.dedeh@kahe.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(171,7,'Atulonge','Mgina','atulonge.mgina@kahe.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(172,7,'Shaina','Shoo','shaina.shoo@kahe.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(173,7,'Bhoke','Matutu','bhoke.matutu@kahe.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(174,7,'Angel','Benard','angel.benard@kahe.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(175,7,'Sarah','Emmanuel','sarah.emmanuel@kahe.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(176,7,'Devotha','Andrea','devotha.andrea@kahe.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(177,7,'Johnson','Raymond','johnson.raymond@kahe.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(178,7,'Jakline','Mkonyi','jakline.mkonyi@kahe.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(179,7,'Zabron','Lupondo','zabron.lupondo@kahe.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(180,7,'Phabiola','Lucas','phabiola.lucas@kahe.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(181,7,'operations','1','operations1@kahe.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(182,7,'operations','2','operations2@kahe.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(183,7,'operations','3','operations3@kahe.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(184,7,'Jesca','Kapinga','jesca.kapinga@kahe.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(185,8,'Hamza','Patwa','hamza.patwa@hapatwa.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(186,8,'Nahdi','Patwa','nahdi.patwa@hapatwa.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(187,8,'Rhuksana','Kapasi','rhuksana.kapasi@hapatwa.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(188,8,'Heeral','Pattni','heeral.pattni@hapatwa.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(189,8,'Happines','Masano','happines.masano@hapatwa.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(190,8,'Amon','Malingumu','amon.malingumu@hapatwa.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(191,8,'Nuru','Hamisi','nuru.hamisi@hapatwa.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(192,8,'Godfrey','Dimoso','godfrey.dimoso@hapatwa.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(193,8,'Gerida','John','gerida.john@hapatwa.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(194,8,'Husain','Fakhruddin','husain.fakhruddin@hapatwa.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(195,8,'Rashida','Shabbir','rashida.shabbir@hapatwa.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(196,8,'Diya','Chudasama','diya.chudasama@hapatwa.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(197,8,'Ebrahim','Khanbhai','ebrahim.khanbhai@hapatwa.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(198,8,'Dhruvi','Vishal','dhruvi.vishal@hapatwa.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(199,8,'Luvae','Juzer','luvae.juzer@hapatwa.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(200,8,'Mufazal','Dawoodji','mufazal.dawoodji1@hapatwa.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(201,8,'Mufazal','Dawoodji','mufazal.dawoodji2@hapatwa.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL),(202,8,'Site','User','site.user@hapatwa.local',NULL,NULL,NULL,NULL,'full_time','active',NULL,'2026-05-23 19:41:18','2026-05-23 19:41:18',NULL);
/*!40000 ALTER TABLE `staff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `timezone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'UTC',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `email_verification_code` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verification_expires_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (2,'Test User','test@example.com','UTC','2026-05-23 07:38:13',NULL,NULL,'$2y$12$DU.zeCEKYT8Yz4LI6w3LfekDwIxbS8hjYvo/NPtgJo6UFVwCNf9qi',NULL,NULL,NULL,'WBjb5EfuaFy9244SqqSVq8w0dYt8aHlor8Hjl9vsdSAGwsF0pbiogLqAuhHE','2026-05-23 07:38:13','2026-05-23 07:38:13',NULL),(3,'Alfred Festo','alfred.festo@wemanage.co.tz','UTC','2026-05-30 03:55:56','355503','2026-05-30 04:06:12','$2y$12$1QWWGr1LKrm9iLEp/lyAnumHaRezuxI7l1LPUyLs2ziL6t2stnprS',NULL,NULL,NULL,'iJnuwfFZb8cOPPKVDJfgR6YrKFnqRyczcFtqD2kSROUaJ1H3ERmrv5U6yHs9','2026-05-29 12:23:27','2026-05-30 03:56:12',NULL),(4,'Suleiman Omar','suleiman.omar@wemanage.co.tz','UTC',NULL,NULL,NULL,'$2y$12$Ha5itUR9pIuiyh.tzmV28eb2xjlSiI3JWAIA.aH13H72ZwYG1VwgC',NULL,NULL,NULL,NULL,'2026-06-01 11:38:06','2026-06-01 11:38:06',NULL),(5,'Taha Rajabali','taha@wemanage.co.tz','UTC',NULL,NULL,NULL,'$2y$12$ZsM70op0rzFVstjjOHDL8uuPs..TxzpFiwjyall08TgQkxoeUeXKm',NULL,NULL,NULL,NULL,'2026-06-01 11:38:33','2026-06-01 11:38:33',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'asset_management'
--

--
-- Dumping routines for database 'asset_management'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-03 13:24:30
